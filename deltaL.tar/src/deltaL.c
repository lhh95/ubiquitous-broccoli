#include <math.h>
#include <string.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>

#include "imageio.h"
#include "procs.h"

/** @brief struct of program parameters */
typedef struct
{
	char 	*InputFile;
	char 	*OutputFile;
} programparams;

static int ParseParams(programparams *Param, int argc, char *argv[]);

/** @brief Print program usage help message */
static void PrintHelpMessage()
{
    	printf("Example:\n"
               "./deltaL input.bmp out.bmp\n");
}

int main(int argc, char *argv[])
{
    	programparams 	Param;

    	float 	*Input = NULL, *Output = NULL;
    	int 	width, height, Status = 1;

    	if(!ParseParams(&Param, argc, argv)) return 0;

/*------------------------------------------------------*/
// Read input image file
/*------------------------------------------------------*/
    	if(!(Input = (float *)ReadImage(&width, &height, Param.InputFile, IMAGEIO_FLOAT | IMAGEIO_RGB | IMAGEIO_PLANAR))) goto Catch;
	if(width < 4 || height < 4) {
	    	ErrorMessage("Image is too small (%dx%d).\n", width, height); goto Catch;
	}
/*------------------------------------------------------*/
	if(!(Output = (float *)Malloc(sizeof(float)*3* ((long int)width)*((long int)height)))) goto Catch;
/*------------------------------------------------------*/
	ColorEnhance(Output, Input, width, height);

/* write the output image */
	if(!WriteImage(Output, width, height, Param.OutputFile, IMAGEIO_FLOAT | IMAGEIO_RGB | IMAGEIO_PLANAR, 80)) goto Catch;
	
	Status = 0; /* Finished successfully, set exit status to zero. */
Catch:
    	Free(Output);
    	Free(Input);

    	return Status;
}

static int ParseParams(programparams *Param, int argc, char *argv[])
{
    	static char *DefaultOutputFile = (char *)"out.png";
    	char *OptionString;
    	char OptionChar;
    	int i;
    
    	if(argc < 2) {
        	PrintHelpMessage();
        	return 0;
    	}

    	/* Set parameter defaults */
    	Param->InputFile = 0;
    	Param->OutputFile = DefaultOutputFile;
    
    	for(i = 1; i < argc;) {
        	if(argv[i] && argv[i][0] == '-') {
        	}
        	else {
            		if(!Param->InputFile) Param->InputFile = argv[i];
            		else Param->OutputFile = argv[i];
        	}
            	i++;
    	}
    
    	if(!Param->InputFile) {
        	PrintHelpMessage();
        	return 0;
    	}
    
    	return 1;
}
