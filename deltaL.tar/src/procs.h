void AutoWB(float *balanced, const float *Input, int Width, int Height, int RedX, int RedY, int wb_enable);
void ColorCorrection(float *corrected, const float *Input, int Width, int Height);
void AGamma(float *o_gamma, const float *Input, int Width, int Height, float gamma);
void ColorEnhance(float *enhanced, const float *Input, int Width, int Height);

