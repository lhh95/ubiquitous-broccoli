#include "basic.h"

#define DELTAL_EN 1
#define GAMMA_EN 1

float 	Xw = 0.951;
float	Yw = 1.000;
float	Zw = 1.089;

float	CW = 1.5;


void 	RGBtoYCbCr(float *YCbCr, float red, float green, float blue)
{
/*
	YCbCr[0] = (float)(0.2215 * red + 0.7154 * green + 0.0721 * blue);
        YCbCr[1] = (float)(-0.1145 * red - 0.3855 * green + 0.5000 * blue);
        YCbCr[2] = (float)(0.5016 * red - 0.4556 * green - 0.0459 * blue);
*/
	YCbCr[0] = (float)(0.2216 * red + 0.7152 * green + 0.0722 * blue);
        YCbCr[1] = (float)(-0.1146 * red - 0.3854 * green + 0.5000 * blue);
        YCbCr[2] = (float)(0.5000 * red - 0.4542 * green - 0.0458 * blue);
}
void 	YCbCrtoRGB(float *RGB, float y, float cb, float cr)
{
	RGB[0] = (float)(y - 0.0002 * cb + 1.5748 * cr);
        RGB[1] = (float)(y - 0.1873 * cb - 0.4681 * cr);
        RGB[2] = (float)(y + 1.8556 * cb + 0.0001 * cr);
}
void	RGBtoXYZ(float *XYZ, float red, float green, float blue)
{
	float r,g,b;

	r=red;
/*
	if(r>0.04045) r=pow(( ( r + 0.055f ) / 1.055f ), 2.4f);
	else          r/=12.92f;
*/

	g=green;
/*
	if(g>0.04045) g=pow(( ( g + 0.055f ) / 1.055f ), 2.4f);
	else          g/=12.92f;
*/

	b=blue;
/*
	if(b>0.04045) b=pow(( ( b + 0.055f ) / 1.055f ), 2.4f);
	else          b/=12.92f;
*/

/*
	r*=100;
	g*=100;
	b*=100;
*/

	XYZ[0] = 0.4124f * r + 0.3576f * g + 0.1805f * b;
        XYZ[1] = 0.2126f * r + 0.7152f * g + 0.0722f * b;
        XYZ[2] = 0.0193f * r + 0.1192f * g + 0.9505f * b;
/*
	XYZ[0] = 0.412453f * r + 0.35758f * g + 0.180423f * b;
        XYZ[1] = 0.212671f * r + 0.71516f * g + 0.072169f * b;
        XYZ[2] = 0.019334f * r + 0.119193f * g + 0.950227f * b;
*/
}
void	XYZtoLAB(float *LAB, float x, float y, float z)
{
	x /= Xw;
	y /= Yw;
	z /= Zw;

	if (x > 0.008856) x=pow(x,0.33f);
	else              x=(7.787f * x) + ( 0.1379310344827586f );

	if (y > 0.008856) y=pow(y,0.33f);
	else              y=(7.787f * y) + ( 0.1379310344827586f );

	if (z > 0.008856) z=pow(z,0.33f);
	else              z=(7.787f * z) + ( 0.1379310344827586f );

	LAB[0] = (116*y)-16;
	LAB[1] = 500*(x-y);
	LAB[2] = 200*(y-z);
}
void	LABtoXYZ(float *XYZ, float l, float a, float b)
{
	float	x,y,z;

	y = ( l + 16.0f ) / 116.0f;
	x = a / 500.0f + y;
	z = y - b / 200.0f;

	if (pow(y,3) > 0.008856) y=pow(y,3);
	else                     y=(( y - 16 / 116. ) / 7.787);
	if (pow(x,3) > 0.008856) x=pow(x,3);
	else                     x=(( x - 16 / 116. ) / 7.787);
	if (pow(z,3) > 0.008856) z=pow(z,3);
	else                     z=(( z - 16 / 116. ) / 7.787);

	XYZ[0] = x*Xw;
	XYZ[1] = y*Yw;
	XYZ[2] = z*Zw;
}

void	XYZtoRGB(float *RGB, float x, float y, float z)
{
/*
	x /= 100;
	y /= 100;
	z /= 100;
*/

	float r,g,b;
	
	r = 3.240479f * x - 1.53715f * y - 0.498535f * z;
        g = -0.969256f * x + 1.875991f * y + 0.041556f * z;
        b = 0.055648f * x - 0.204043f * y + 1.057311f * z;
	
/*
	if(r>0.0031308) r=1.055f*pow(r,0.4166f)-0.055f;
	else            r*=12.92f;

	if(g>0.0031308) g=1.055f*pow(g,0.4166f)-0.055f;
	else            g*=12.92f;

	if(b>0.0031308) b=1.055f*pow(b,0.4166f)-0.055f;
	else            b*=12.92f;
*/

	RGB[0] = r;
        RGB[1] = g;
        RGB[2] = b;
}

void AutoWB(float *balanced, const float *Input, int Width, int Height, int RedX, int RedY, int wb_enable)
{
    	const int 	Green = 1 - ((RedX + RedY) & 1);
    	int 		i, x, y;

	float	sumR=0;
	float	sumG=0;
	float	sumB=0;
	int	cntR=0;
	int	cntG=0;
	int	cntB=0;
	float	r_gain, b_gain;

/*------------------------------------------------------*/
// Accumulate pixel for each color channel(r,g,b)
/*------------------------------------------------------*/
    	for(y = 0, i = 0; y < Height; y++)
        	for(x = 0; x < Width; x++, i++) {
            		if(((x + y) & 1) == Green) {
				sumG += Input[i];
				cntG++;
			}
            		else if((y & 1) == RedY) {
				sumR += Input[i];
				cntR++;
			}
            		else {
				sumB += Input[i];
				cntB++;
			}
        	}
/*------------------------------------------------------*/
// Calculate gain
/*------------------------------------------------------*/
	r_gain = (sumG/(float)cntG)/(sumR/(float)cntR);
	b_gain = (sumG/(float)cntG)/(sumB/(float)cntB);
/*------------------------------------------------------*/
// Apply gains for white balance
/*------------------------------------------------------*/
    	for(y = 0, i = 0; y < Height; y++)
        	for(x = 0; x < Width; x++, i++) {
            		if(((x + y) & 1) == Green) {
				balanced[i] = Input[i];
			}
            		else if((y & 1) == RedY) {
				if(wb_enable==1) balanced[i] = Input[i]*r_gain;
				else balanced[i] = Input[i];
			}
            		else {
				if(wb_enable==1) balanced[i] = Input[i]*b_gain;
				else balanced[i] = Input[i];
			}
        	}
}


void ColorCorrection (float *corrected, const float *Input, int Width, int Height)
{

	int	numpixels = Width*Height;

	float	*ired = Input;
	float	*igre = Input+numpixels;
	float	*iblu = Input+numpixels*2;

	float	*ored = corrected;
	float	*ogre = corrected+numpixels;
	float	*oblu = corrected+numpixels*2;

	int	x,y,i;
	float	ccm[3][3] = {{1.0, 0.0, 0.0},
                             {0.0, 1.0, 0.0},
                             {0.0, 0.0, 1.0}};

	for(y=0,i=0;y<Height;y++)
                for(x=0;x<Width;x++,i++) {
                        ored[i] = ccm[0][0]*ired[i] + ccm[0][1]*igre[i] + ccm[0][2]*iblu[i];
                        ogre[i] = ccm[1][0]*ired[i] + ccm[1][1]*igre[i] + ccm[1][2]*iblu[i];
                        oblu[i] = ccm[2][0]*ired[i] + ccm[2][1]*igre[i] + ccm[2][2]*iblu[i];
                }
}

void AGamma (float *o_gamma, const float *Input, int Width, int Height, float gamma)
{
	int	numpixels = Width*Height;

	float	*ired = Input;
	float	*igre = Input+numpixels;
	float	*iblu = Input+numpixels*2;

	float	*ored = o_gamma;
	float	*ogre = o_gamma+numpixels;
	float	*oblu = o_gamma+numpixels*2;

	int	x,y,i;

	double	tr, tg, tb;

	for(y=0,i=0;y<Height;y++)
                for(x=0;x<Width;x++,i++) {
                        tr = pow(ired[i], 1./gamma);
                        tg = pow(igre[i], 1./gamma);
                        tb = pow(iblu[i], 1./gamma);
                        ored[i] = tr;
                        ogre[i] = tg;
                        oblu[i] = tb;
                }
}
void ColorEnhance (float *enhanced, const float *Input, int Width, int Height)
{

	int	numpixels = Width*Height;

	float	*ired = Input;
	float	*igre = Input+numpixels;
	float	*iblu = Input+numpixels*2;

	float	*ored = enhanced;
	float	*ogre = enhanced+numpixels;
	float	*oblu = enhanced+numpixels*2;

	int	x,y,i;

	float	y0, cb0, cr0;
	float	YCbCr[3], RGB[3], XYZ[3], LAB[3];
	float	nLAB[3], nYCbCr[3];
	float	gamma = 2.2;
	float	previousY, deltaL;

	for(y=0,i=0;y<Height;y++)
                for(x=0;x<Width;x++,i++) {
/*------------------------------------------------------*/
// RGB2YUV conversion 
/*------------------------------------------------------*/
			RGBtoYCbCr(YCbCr,ired[i],igre[i],iblu[i]);
/*------------------------------------------------------*/
// Delta L compensation
/*------------------------------------------------------*/
			YCbCrtoRGB(RGB,YCbCr[0],YCbCr[1],YCbCr[2]);

#if GAMMA_EN
			RGB[0] = (RGB[0]<0)?0.0:(RGB[0]>1.0)?1.0:pow(RGB[0], gamma);
			RGB[1] = (RGB[1]<0)?0.0:(RGB[1]>1.0)?1.0:pow(RGB[1], gamma);
			RGB[2] = (RGB[2]<0)?0.0:(RGB[2]>1.0)?1.0:pow(RGB[2], gamma);
#endif
			RGBtoXYZ(XYZ,RGB[0],RGB[1],RGB[2]);
			XYZtoLAB(LAB,XYZ[0],XYZ[1],XYZ[2]);

			nLAB[0]=LAB[0];			// store original L
/*------------------------------------------------------*/
// apply chroma weight
/*------------------------------------------------------*/
			YCbCrtoRGB(RGB,YCbCr[0],YCbCr[1]*CW,YCbCr[2]*CW);
/*------------------------------------------------------*/
#if GAMMA_EN
			RGB[0] = (RGB[0]<0)?0.0:(RGB[0]>1.0)?1.0:pow(RGB[0], gamma);
			RGB[1] = (RGB[1]<0)?0.0:(RGB[1]>1.0)?1.0:pow(RGB[1], gamma);
			RGB[2] = (RGB[2]<0)?0.0:(RGB[2]>1.0)?1.0:pow(RGB[2], gamma);
#endif
			RGBtoXYZ(XYZ,RGB[0],RGB[1],RGB[2]);
			XYZtoLAB(LAB,XYZ[0],XYZ[1],XYZ[2]);

			if(DELTAL_EN==0) nLAB[0]=LAB[0];
			nLAB[1]=LAB[1];
			nLAB[2]=LAB[2];

			LABtoXYZ(XYZ,nLAB[0],nLAB[1],nLAB[2]);
			XYZtoRGB(RGB,XYZ[0],XYZ[1],XYZ[2]);
#if GAMMA_EN
			RGB[0] = (RGB[0]<0)?0.0:(RGB[0]>1.0)?1.0:pow(RGB[0], 1/gamma);
			RGB[1] = (RGB[1]<0)?0.0:(RGB[1]>1.0)?1.0:pow(RGB[1], 1/gamma);
			RGB[2] = (RGB[2]<0)?0.0:(RGB[2]>1.0)?1.0:pow(RGB[2], 1/gamma);
#endif
/*
			RGBtoYCbCr(nYCbCr,RGB[0],RGB[1],RGB[2]);

			YCbCrtoRGB(RGB,nYCbCr[0],nYCbCr[1],nYCbCr[2]);

			RGB[0] = (RGB[0]<0)?0.0:(RGB[0]>1.0)?1.0:RGB[0];
			RGB[1] = (RGB[1]<0)?0.0:(RGB[1]>1.0)?1.0:RGB[1];
			RGB[2] = (RGB[2]<0)?0.0:(RGB[2]>1.0)?1.0:RGB[2];
*/
			ored[i]=RGB[0];
			ogre[i]=RGB[1];
			oblu[i]=RGB[2];
                }

}
