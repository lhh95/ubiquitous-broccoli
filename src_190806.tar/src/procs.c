#define BT709 1
#include "basic.h"

void AutoWB(float *balanced, const float *Input, int Width, int Height, int RedX, int RedY, int wb_enable)
{
    	const int 	Green = 1 - ((RedX + RedY) & 1);
    	int 		i, x, y;

	float	sumR=0;
	float	sumG=0;
	float	sumB=0;
	int	cntR=0;
	int	cntG=0;
	int	cntB=0;
	float	r_gain, b_gain;

/*------------------------------------------------------*/
// Accumulate pixel for each color channel(r,g,b)
/*------------------------------------------------------*/
    	for(y = 0, i = 0; y < Height; y++)
        	for(x = 0; x < Width; x++, i++) {
            		if(((x + y) & 1) == Green) {
				sumG += Input[i];
				cntG++;
			}
            		else if((y & 1) == RedY) {
				sumR += Input[i];
				cntR++;
			}
            		else {
				sumB += Input[i];
				cntB++;
			}
        	}
/*------------------------------------------------------*/
// Calculate gain
/*------------------------------------------------------*/
	r_gain = (sumG/(float)cntG)/(sumR/(float)cntR);
	b_gain = (sumG/(float)cntG)/(sumB/(float)cntB);
/*------------------------------------------------------*/
// Apply gains for white balance
/*------------------------------------------------------*/
    	for(y = 0, i = 0; y < Height; y++)
        	for(x = 0; x < Width; x++, i++) {
            		if(((x + y) & 1) == Green) {
				balanced[i] = Input[i];
			}
            		else if((y & 1) == RedY) {
				if(wb_enable==1) balanced[i] = Input[i]*r_gain;
				else balanced[i] = Input[i];
			}
            		else {
				if(wb_enable==1) balanced[i] = Input[i]*b_gain;
				else balanced[i] = Input[i];
			}
        	}
}


void ColorCorrection (float *corrected, const float *Input, int Width, int Height)
{

	int	numpixels = Width*Height;

	float	*ired = Input;
	float	*igre = Input+numpixels;
	float	*iblu = Input+numpixels*2;

	float	*ored = corrected;
	float	*ogre = corrected+numpixels;
	float	*oblu = corrected+numpixels*2;

	int	x,y,i;
	float	ccm[3][3] = {{1.0, 0.0, 0.0},
                             {0.0, 1.0, 0.0},
                             {0.0, 0.0, 1.0}};

	for(y=0,i=0;y<Height;y++)
                for(x=0;x<Width;x++,i++) {
                        ored[i] = ccm[0][0]*ired[i] + ccm[0][1]*igre[i] + ccm[0][2]*iblu[i];
                        ogre[i] = ccm[1][0]*ired[i] + ccm[1][1]*igre[i] + ccm[1][2]*iblu[i];
                        oblu[i] = ccm[2][0]*ired[i] + ccm[2][1]*igre[i] + ccm[2][2]*iblu[i];
                }
}

void AGamma (float *o_gamma, const float *Input, int Width, int Height, float gamma)
{
	int	numpixels = Width*Height;

	float	*ired = Input;
	float	*igre = Input+numpixels;
	float	*iblu = Input+numpixels*2;

	float	*ored = o_gamma;
	float	*ogre = o_gamma+numpixels;
	float	*oblu = o_gamma+numpixels*2;

	int	x,y,i;

	double	tr, tg, tb;

	for(y=0,i=0;y<Height;y++)
                for(x=0;x<Width;x++,i++) {
                        tr = pow(ired[i], 1./gamma);
                        tg = pow(igre[i], 1./gamma);
                        tb = pow(iblu[i], 1./gamma);
                        ored[i] = tr;
                        ogre[i] = tg;
                        oblu[i] = tb;
                }
}
void ColorEnhance (float *enhanced, const float *Input, int Width, int Height)
{

	int	numpixels = Width*Height;

	float	*ired = Input;
	float	*igre = Input+numpixels;
	float	*iblu = Input+numpixels*2;

	float	*ored = enhanced;
	float	*ogre = enhanced+numpixels;
	float	*oblu = enhanced+numpixels*2;

	int	x,y,i;

	float	y0, cb0, cr0;

	for(y=0,i=0;y<Height;y++)
                for(x=0;x<Width;x++,i++) {
/*------------------------------------------------------*/
// RGB2YUV conversion 
/*------------------------------------------------------*/
#if BT709
			y0=ired[i]*0.2126 + igre[i]*0.7152 + iblu[i]*0.0722;
			cb0=-ired[i]*0.09991 - igre[i]*0.33609 + iblu[i]*0.436;
			cr0=ired[i]*0.615 - igre[i]*0.55861 - iblu[i]*0.05639;
#else

			y0=ired[i]*0.299 + igre[i]*0.587 + iblu[i]*0.114;
			cb0=-ired[i]*0.147 - igre[i]*0.289 + iblu[i]*0.436;
			cr0=ired[i]*0.615 - igre[i]*0.515 - iblu[i]*0.100;
#endif
/*------------------------------------------------------*/
// color enhancement algorithm should be placed here
/*------------------------------------------------------*/

//			printf("y=%d x=%d y0=%f cb0=%f cr0=%f r=%f g=%f b=%f\n",y,x,y0,cb0,cr0,ired[i],igre[i],iblu[i]);

/*------------------------------------------------------*/
// Even though ISP final output format is YUV,
// we need to convert RGB format again to store 
// processing result to image file.
//
// YUV2RGB conversion 
/*------------------------------------------------------*/
#if BT709
			ored[i]=(y0+cr0*1.28033);
			ogre[i]=(y0-cb0*0.21482-cr0*0.38059);
			oblu[i]=(y0+cb0*2.12798);
#else 
			ored[i]=(y0+cr0*1.14);
			ogre[i]=(y0-cb0*0.39-cr0*0.58);
			oblu[i]=(y0+cb0*2.03);
#endif
                }
}
