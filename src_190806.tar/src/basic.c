#include <stdlib.h>
#include <stdarg.h>
#include "basic.h"


/** @brief malloc with an error message on failure. */
void *MallocWithErrorMessage(size_t Size)
{
    void *Ptr;
    
    if(!(Ptr = malloc(Size)))
        ErrorMessage("Memory allocation of %u bytes failed.\n", Size);
        
    return Ptr;
}


/** @brief realloc with an error message and free on failure. */
void *ReallocWithErrorMessage(void *Ptr, size_t Size)
{
    void *NewPtr;
    
    if(!(NewPtr = realloc(Ptr, Size)))
    {
        ErrorMessage("Memory reallocation of %u bytes failed.\n", Size);
        Free(Ptr);  /* Free the previous block on failure */
    }
        
    return NewPtr;
}


/** @brief Redefine this function to customize error messages. */
void ErrorMessage(const char *Format, ...)
{
    va_list Args;
    
    va_start(Args, Format);
    /* Write a formatted error message to stderr */
    vfprintf(stderr, Format, Args);
    va_end(Args);
}


#if defined(WIN32) || defined(_WIN32) || defined(WIN64) || defined(_WIN64)
/* Windows: implement with GetSystemTime */
	
#define WIN32_LEAN_AND_MEAN
#include <windows.h>

/* Clock:  Get the system clock in milliseconds */
unsigned long Clock()
{
	static SYSTEMTIME TimeVal;
	GetSystemTime(&TimeVal);
	return (unsigned long)((unsigned long)TimeVal.wMilliseconds
		+ 1000*((unsigned long)TimeVal.wSecond
		+ 60*((unsigned long)TimeVal.wMinute 
		+ 60*((unsigned long)TimeVal.wHour 
		+ 24*(unsigned long)TimeVal.wDay))));
}

#else
/* UNIX: implement with gettimeofday */

#include <sys/time.h>
#include <unistd.h>

/* Clock:  Get the system clock in milliseconds */
unsigned long Clock()
{
	struct timeval TimeVal;
	gettimeofday(&TimeVal, NULL); 
	return (unsigned long)(TimeVal.tv_usec/1000 + TimeVal.tv_sec*1000);
}

#endif
