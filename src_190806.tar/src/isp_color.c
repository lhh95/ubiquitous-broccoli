#include <math.h>
#include <string.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>

#include "imageio.h"
#include "dmbilinear.h"
#include "dmzhangwu.h"
#include "procs.h"

/** @brief struct of program parameters */
typedef struct
{
	char 	*InputFile;
	char 	*OutputFile;
	int  	JpegQuality;
	int	RedX;
	int	RedY;
} programparams;

static int ParseParams(programparams *Param, int argc, char *argv[]);

/** @brief Print program usage help message */
static void PrintHelpMessage()
{
    	printf("Example:\n"
               "./isp_color -p bggr input.bmp out.bmp\n");
}

int main(int argc, char *argv[])
{
    	programparams 	Param;

    	float 	*Input = NULL, *Output = NULL;
    	int 	width, height, Status = 1;

	int	wb_enable=0;
	float	gamma=2.2;

    	if(!ParseParams(&Param, argc, argv)) return 0;

/*------------------------------------------------------*/
// Read input image file
/*------------------------------------------------------*/
    	if(!(Input = (float *)ReadImage(&width, &height, Param.InputFile, IMAGEIO_FLOAT | IMAGEIO_RGB | IMAGEIO_PLANAR))) goto Catch;
	if(width < 4 || height < 4) {
	    	ErrorMessage("Image is too small (%dx%d).\n", width, height); goto Catch;
	}
/*------------------------------------------------------*/
	if(!(Output = (float *)Malloc(sizeof(float)*3* ((long int)width)*((long int)height)))) goto Catch;
/*------------------------------------------------------*/
// Make bayer format 
/*------------------------------------------------------*/
	CfaFlatten(Input, Input, width, height, Param.RedX, Param.RedY);
/*------------------------------------------------------*/
// Auto white balance
/*------------------------------------------------------*/
	AutoWB(Input, Input, width, height, Param.RedX, Param.RedY, wb_enable);
/*------------------------------------------------------*/
// Demosaicking
/*------------------------------------------------------*/
	ZhangWuDemosaic(Input, Input, width, height, Param.RedX, Param.RedY, 0);
/*------------------------------------------------------*/
// Color correction
/*------------------------------------------------------*/
	ColorCorrection(Input, Input, width, height);
/*------------------------------------------------------*/
// Apply gamma 
/*------------------------------------------------------*/
	AGamma(Input, Input, width, height, gamma);
/*------------------------------------------------------*/
// Color enhancement
/*------------------------------------------------------*/
	ColorEnhance(Output, Input, width, height);

/* write the output image */
	if(!WriteImage(Output, width, height, Param.OutputFile, IMAGEIO_FLOAT | IMAGEIO_RGB | IMAGEIO_PLANAR, Param.JpegQuality)) goto Catch;
	
	Status = 0; /* Finished successfully, set exit status to zero. */
Catch:
    	Free(Output);
    	Free(Input);

    	return Status;
}

static int ParseParams(programparams *Param, int argc, char *argv[])
{
    	static char *DefaultOutputFile = (char *)"out.png";
    	char *OptionString;
    	char OptionChar;
    	int i;
    
    	if(argc < 2) {
        	PrintHelpMessage();
        	return 0;
    	}

    	/* Set parameter defaults */
    	Param->InputFile = 0;
    	Param->OutputFile = DefaultOutputFile;
    	Param->JpegQuality = 80;
    	Param->RedX = 0;
    	Param->RedY = 0;
    
    	for(i = 1; i < argc;) {
        	if(argv[i] && argv[i][0] == '-') {
            		if((OptionChar = argv[i][1]) == 0) {
                		printf("Invalid parameter format.\n");
                		return 0;
            		}

            		if(argv[i][2]) OptionString = &argv[i][2];
            		else if(++i < argc) OptionString = argv[i];
            		else {
                		printf("Invalid parameter format.\n");
                		return 0;
            		}
            
            		switch(OptionChar) {
            		case 'p':
                		if(!strcmp(OptionString, "RGGB") 
                    		|| !strcmp(OptionString, "rggb")) {
                    			Param->RedX = 0;
                    			Param->RedY = 0;
                		}
                		else if(!strcmp(OptionString, "GRBG") 
                    		|| !strcmp(OptionString, "grbg")) {
                    			Param->RedX = 1;
                    			Param->RedY = 0;
                		}
                		else if(!strcmp(OptionString, "GBRG") 
                    		|| !strcmp(OptionString, "gbrg")) {
                    			Param->RedX = 0;
                    			Param->RedY = 1;
                		}
                		else if(!strcmp(OptionString, "BGGR") 
                    		|| !strcmp(OptionString, "bggr")) {
                    			Param->RedX = 1;
                    			Param->RedY = 1;
                		}
                		else printf("CFA pattern must be RGGB, GRBG, GBRG, or BGGR.\n");
                		break;
            		default:
                		if(isprint(OptionChar)) printf("Unknown option \"-%c\".\n", OptionChar);
                		else printf("Unknown option.\n");
                		return 0;
            		}
        	}
        	else {
            		if(!Param->InputFile) Param->InputFile = argv[i];
            		else Param->OutputFile = argv[i];

        	}
            	i++;
    	}
    
    	if(!Param->InputFile) {
        	PrintHelpMessage();
        	return 0;
    	}
    
    	return 1;
}
